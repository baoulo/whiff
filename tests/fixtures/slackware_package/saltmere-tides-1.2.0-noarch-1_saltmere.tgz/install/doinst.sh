( cd usr/bin ; ln -sf saltmere-tides tides )
